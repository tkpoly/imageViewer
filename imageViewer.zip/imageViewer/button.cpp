﻿// button.cpp : 実装ファイル
//

#include "pch.h"
#include "imageViewer.h"
#include "button.h"


// Cbutton

IMPLEMENT_DYNAMIC(Cbutton, CWnd)

Cbutton::Cbutton()
{
	//ボタン
	btN = 9;
	btname[0] = _T("Load Image");
	btname[1] = _T("display Size");
	btname[2] = _T("");
	btname[3] = _T("");
	btname[4] = _T("");
	btname[5] = _T("Save Image");
	btname[6] = _T("―");
	btname[7] = _T("□");
	btname[8] = _T("X");

	setBT();//仮、まだWidth,Heightが決まってない

	btNoD = -1;
	reset();
}

Cbutton::~Cbutton()
{
	DeleteObject(hbrHaikei);
}


BEGIN_MESSAGE_MAP(Cbutton, CWnd)
END_MESSAGE_MAP()



// Cbutton メッセージ ハンドラー
//DCをセット*************************************************************************************
void Cbutton::setDC(HWND hwnd, CDC* pDc, CDC* pdc, HDC hdc, int width, int height, COLORREF haikei)
{
	hWnd = hwnd;
	pDC = pDc;

	pdcBack = pdc;
	hdcBack = hdc;
	Width = width;
	Height = height;
	Haikei = haikei;
	hbrHaikei = CreateSolidBrush(Haikei);
}


//DCをセット*************************************************
void Cbutton::setWSize(int width, int height)
{
	Width = width;
	Height = height;

	setBT();
	redraw();
}




//ボタンを設定*********************************************************************
void Cbutton::setBT()
{
	int ofX = 20;
	int	ofY = Height/2;
	int W = 180;
	int H = 30;

	btRect[0].left = ofX;	btRect[0].top = ofY;
	btRect[0].right = btRect[0].left + W;	btRect[0].bottom = btRect[0].top + H;

	btRect[1].left = btRect[0].right + ofX + 20;	btRect[1].top = ofY;
	btRect[1].right = btRect[1].left + W;	btRect[1].bottom = btRect[1].top + H;

	btRect[2].left = btRect[1].right + ofX + 160;	btRect[2].top = ofY;
	btRect[2].right = btRect[2].left + 140;	btRect[2].bottom = btRect[2].top + H;

	btRect[3].left = btRect[2].right + ofX + 20;	btRect[3].top = ofY;
	btRect[3].right = btRect[3].left + 140;	btRect[3].bottom = btRect[3].top + H;

	btRect[4].left = btRect[3].right + ofX + 20;	btRect[4].top = ofY;
	btRect[4].right = btRect[4].left + 140;	btRect[4].bottom = btRect[4].top + H;

	btRect[5].left = btRect[4].right + ofX + 100;	btRect[5].top = ofY;
	btRect[5].right = btRect[5].left + W;	btRect[5].bottom = btRect[5].top + H;


	btRect[6].left = Width - 200;	btRect[6].top = 10;
	btRect[6].right = btRect[6].left + 40;	btRect[6].bottom = btRect[6].top + 26;

	btRect[7].left = Width - 140;	btRect[7].top = 10;
	btRect[7].right = btRect[7].left + 40;	btRect[7].bottom = btRect[7].top + 26;

	btRect[8].left = Width - 80;	btRect[8].top = 10;
	btRect[8].right = btRect[8].left + 40;	btRect[8].bottom = btRect[8].top + 26;

	//テキスト
	tex[0] = _T("Auto");
	texRect[0] = { btRect[1].right ,btRect[1].top,
						btRect[1].right + 60,btRect[1].bottom };
}



//全ボタンをリセット*******************************************
void Cbutton::reset()
{
	fg_auto = 1;
	tex[0] = _T("Auto");
}


//全ボタンを再描画********************************************
void Cbutton::redraw()
{
	clearBack(hdcBack, Width, Height, Haikei);

	COLORREF texCol = RGB(240, 240, 255);
	RECT rect = { 10,4,1600,36 };
	drawText(WText, rect, 18, FW_NORMAL, texCol, 0);

	//ボタン
	COLORREF bkCol = RGB(100, 100, 120);//ボタン・カラー
	CBrush bkBr(bkCol);

	int nh = 20;
	UINT nF = DT_CENTER | DT_VCENTER | DT_SINGLELINE;

	for (int i = 0; i < btN; i++)
	{
		texCol = RGB(250, 250, 250);
		if (i == 7) {
			texCol = RGB(140, 140, 140);
		}

		pdcBack->FillRect(&btRect[i], &bkBr);
		drawText(btname[i], btRect[i], nh, FW_BOLD, texCol, nF);
	}

	//display size％表示
	texCol = RGB(250, 250, 250);
	if (fg_auto == 1) {
		texCol = RGB(0, 255, 50);
	}
	pdcBack->FillRect(&texRect[0], &bkBr);
	drawText(tex[0], texRect[0], nh, FW_BOLD, texCol, nF);

	pDC->BitBlt(0, 0, Width, Height, pdcBack, 0, 0, SRCCOPY);
}

//ズームの表示率を描画****************************
void Cbutton::drawZPersent(float zBi)
{
	char a[20];
	_itoa_s((int)(zBi * 100.0f), a, 10, 10);
	tex[0] = (CString)a + _T("%");
	redraw();
}



//ボタンダウン・アップ検出***********************************************************
void Cbutton::scanBT(int mxD, int myD, int mxU, int myU)
{
	int i;

	btNoD = -1;
	for (i = 0; i < btN; i++)
	{
		if (mxD > btRect[i].left && mxD<btRect[i].right && myD>btRect[i].top
			&& myD < btRect[i].bottom)
		{
			btNoD = i;
			break;
		}
	}

	btNoU = -2;
	for (i = 0; i < btN; i++)
	{
		if (mxU > btRect[i].left && mxU<btRect[i].right && myU>btRect[i].top
			&& myU < btRect[i].bottom)
		{
			btNoU = i;

			if (btNoD == -1 || btNoU != btNoD) {
				;
			}
			else {//down=UP
				if (btNoU == 0) {//loadImage
					;
				}
				else if (btNoU == 1) {//display size
					if (fg_auto == 0) {
						fg_auto = 1;
						tex[0] = _T("Auto");
					}
					else {
						fg_auto = 0;
						tex[0] = _T("100%");
					}
					redraw();
				}
				else if (btNoU == 2) {//
					//redraw();
				}
				else if (btNoU == 3) {//
					//redraw();
				}
				else if (btNoU == 4) {//
					//redraw();
				}
				else if (btNoU == 5) {//save Image
					;
				}
				else if (btNoU == 6) {//-
					;
				}
				else if (btNoU == 7) {//□
					;
				}
				else if (btNoU == 8) {//X
					;
				}

				redraw();
				if (btname[btNoU] != L"") {
					::PostMessageW(hWnd, WM_BT, btNoU, 1);
				}
			}

			break;
		}
	}

}


//Backバッファを任意の色でクリア************************************
void Cbutton::clearBack(HDC hdc, int w, int h, COLORREF Col)
{
	RECT rect = { 0,0,w,h };
	CBrush cbr(Col);
	FillRect(hdc, &rect, (HBRUSH)cbr);
	cbr.DeleteObject();
}


//テキストを描画*************************************************************************
void Cbutton::drawText(CString str, RECT rect, int nh, int ef, COLORREF txCol, UINT nF)
{
	nh = (int)((float)nh * 1.33f);

	//新しいフォントを取得---------------------------------
	CFont font;
	font.CreateFont(
		nh,                        // nHeight
		0,                         // nWidth
		0,                         // nEscapement
		0,                         // nOrientation
		ef,						   // FW_NORMAL,
		FALSE,                     // bItalic
		FALSE,                     // bUnderline
		FALSE,                     // cStrikeOut
		SHIFTJIS_CHARSET,          // nCharSet
		OUT_DEFAULT_PRECIS,        // nOutPrecision
		CLIP_DEFAULT_PRECIS,       // nClipPrecision
		DEFAULT_QUALITY,           // nQuality
		VARIABLE_PITCH | FF_SWISS,//ROMAN, // nPitchAndFamily
		_T("Yu Gothic UI"));					  // lpszFacename

	//新しいフォント選択する
	CFont* def_font = pdcBack->SelectObject(&font);

	//新しいフォントで描画--------------------------------
	CBrush cbr(Haikei);
	FillRect(hdcBack, &rect, (HBRUSH)cbr);
	cbr.DeleteObject();

	//pdcBack->SetBkColor(Haikei);
	pdcBack->SetBkMode(TRANSPARENT);
	pdcBack->SetTextColor(txCol);

	UINT nFormat = DT_LEFT | DT_VCENTER | DT_SINGLELINE;
	if (nF != 0) {
		nFormat = nF;
	}

	CRect crect;
	crect.left = rect.left;
	crect.top = rect.top;
	crect.right = rect.right;
	crect.bottom = rect.bottom;

	pdcBack->DrawText(str, crect, nFormat);

	//fontの開放
	font.DeleteObject();

}





