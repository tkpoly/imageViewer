﻿
// imageViewerDlg.h : ヘッダー ファイル
//

#pragma once
#include "button.h"


using namespace Gdiplus;

#define SAFE_RELEASE(p) \
do { if ((p) != nullptr) { (p)->Release(); (p) = nullptr; }} while (0);



// CimageViewerDlg ダイアログ
class CimageViewerDlg : public CDialogEx
{
// コンストラクション
public:
	CimageViewerDlg(CWnd* pParent = nullptr);	// 標準コンストラクター
	
	Cbutton		bt;				//ボタンクラス

	CDC* pDC;
	HDC	 hDC;
	HWND hWnd;

	int				Width = 1800;
	int				Height = 1012;
	COLORREF		Haikei;
	HBRUSH			hbrHaikei;
	int				btH;				//ボタン領域の高さ
	COLORREF		btHaikei;			//ボタン領域の背景色
	int				fg_moveWindow = 0;
	RECT			WRECT;

	int				VWidth, VHeight;	//ビューポート
	int				ofX, ofY;			//ビューポートのオフセット
	int				ofBX, ofBY;			//ビューポートにおける、表示画像のオフセット
	int				imgW = 0;			//元画像の幅
	int				imgH = 0;			//元画像の高さ
	int				imgWmax = 16000;
	int				imgHmax = 16000;
	int				imgWZ = 0;
	int				imgHZ = 0;
	int				VX0, VY0, VX1, VY1;	//スクリーンに表示されている元画像の座標
	int				sX, sY, bsX, bsY;	//スクリーンの中心に対応する元画像の位置座標

	int				mxD, myD, mxM, myM, mxU, myU;//マウスポインタの座標
	int				mxDW, myDW, mxMW, myMW;
	int				bmxM, bmyM;
	float			zBi;
	float			bzBi;
	float			autozBi;
	float			zV = 0.0f;			// ズーム速度
	int				hwZD;				//マウスホイールの移動量（一定値）
	float			zStep;				//ズーム・ステップ
	int				tmCT;				//ズーム・ステップカウンター

	CImage			imgBack0;		//α付32ビット　元画像　
	CDC* pdcBack0;
	HDC				hdcBack0;

	CImage			imgBack;		//α付32ビット　スクリーン・バッファ　
	CDC* pdcBack;
	HDC				hdcBack;

	CImage			imgBT;			//α付32ビット　ボタン領域描画用
	CDC* pdcBT;
	HDC				hdcBT;


	//GDI+ ----------------------------
	GdiplusStartupInput gsi;
	ULONG_PTR		token;



	void			cancel();
	void			scroll(int mxm, int mym);
	void			zoom();
	void			changeAuto_100();
	void			Auto();
	void			disp();
	void			file(int);
	int				loadImage(CString);
	void			saveImage(CString);
	void			clearBack(HDC, int, int, COLORREF);

private:
	Gdiplus::Image* Img;




// ダイアログ データ
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_IMAGEVIEWER_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV サポート


// 実装
protected:
	HICON m_hIcon;

	// 生成された、メッセージ割り当て関数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedOk();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg LRESULT  OnBT(WPARAM wParam, LPARAM lParam);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
