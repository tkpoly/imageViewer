﻿
// imageViewerDlg.cpp : 実装ファイル
//

#include "pch.h"
#include "framework.h"
#include "imageViewer.h"
#include "imageViewerDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// アプリケーションのバージョン情報に使われる CAboutDlg ダイアログ

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// ダイアログ データ
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV サポート

// 実装
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CimageViewerDlg ダイアログ



CimageViewerDlg::CimageViewerDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_IMAGEVIEWER_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CimageViewerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CimageViewerDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_LBUTTONDOWN()
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDOK, &CimageViewerDlg::OnBnClickedOk)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_MESSAGE(WM_BT, OnBT)	//CbuttonDlgクラスからのポストメッセージ
	ON_WM_MOUSEWHEEL()
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CimageViewerDlg メッセージ ハンドラー

BOOL CimageViewerDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// "バージョン情報..." メニューをシステム メニューに追加します。

	// IDM_ABOUTBOX は、システム コマンドの範囲内になければなりません。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// このダイアログのアイコンを設定します。アプリケーションのメイン ウィンドウがダイアログでない場合、
	//  Framework は、この設定を自動的に行います。
	SetIcon(m_hIcon, TRUE);			// 大きいアイコンの設定
	SetIcon(m_hIcon, FALSE);		// 小さいアイコンの設定

	// TODO: 初期化をここに追加します。
	hWnd = this->m_hWnd;
	pDC = GetDC();
	hDC = pDC->GetSafeHdc();
	Haikei = RGB(60, 60, 60);
	hbrHaikei = CreateSolidBrush(Haikei);

	Width = 1800;
	Height = 1012;
	Haikei = RGB(60, 60, 60);
	hbrHaikei = CreateSolidBrush(Haikei);
	btHaikei = RGB(80, 80, 90);


	SetWindowPos(&wndTop, 60, 10, Width, Height, SWP_SHOWWINDOW);

	RECT crect;
	GetClientRect(&crect);
	Width = crect.right;	//初期値
	Height = crect.bottom;	//初期値

	//Windowの角を丸める
	HRGN hRgn = CreateRoundRectRgn(crect.left, crect.top, crect.right, crect.bottom, 16, 16);
	SetWindowRgn(hRgn, TRUE);

	ofX = 0;
	ofY = 100;
	btH = ofY;//ボタン領域の高さ

	VWidth = crect.right - ofX;
	VHeight = crect.bottom - ofY;

	imgW = VWidth;	//仮
	imgH = VHeight;	//仮

	imgBack0.Destroy();
	imgBack0.CreateEx(VWidth, VHeight, 32, BI_RGB, 0, CImage::createAlphaChannel);
	pdcBack0 = CDC::FromHandle(imgBack0.GetDC());
	hdcBack0 = pdcBack0->GetSafeHdc();
	clearBack(hdcBack0, VWidth, VHeight, Haikei);

	imgBack.Destroy();
	imgBack.CreateEx(VWidth, VHeight, 32, BI_RGB, 0, CImage::createAlphaChannel);
	pdcBack = CDC::FromHandle(imgBack.GetDC());
	hdcBack = pdcBack->GetSafeHdc();
	clearBack(hdcBack, VWidth, VHeight, Haikei);

	imgBT.Destroy();
	imgBT.CreateEx(Width, btH, 32, BI_RGB, 0, CImage::createAlphaChannel);
	pdcBT = CDC::FromHandle(imgBT.GetDC());
	hdcBT = pdcBT->GetSafeHdc();
	clearBack(hdcBT, Width, btH, btHaikei);

	pDC->SetStretchBltMode(COLORONCOLOR);
	pdcBack0->SetStretchBltMode(COLORONCOLOR);
	pdcBack->SetStretchBltMode(COLORONCOLOR);


	//Cbutton（メインボタン）
	bt.setDC(hWnd, pDC, pdcBT, hdcBT, Width, btH, btHaikei);
	bt.setBT();

	//GDI+の初期化
	GdiplusStartup(&token, &gsi, NULL);
	ARGB();	//αチャンネル付きカラーを使う


	return TRUE;  // フォーカスをコントロールに設定した場合を除き、TRUE を返します。
}

void CimageViewerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// ダイアログに最小化ボタンを追加する場合、アイコンを描画するための
//  下のコードが必要です。ドキュメント/ビュー モデルを使う MFC アプリケーションの場合、
//  これは、Framework によって自動的に設定されます。

void CimageViewerDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 描画のデバイス コンテキスト

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// クライアントの四角形領域内の中央
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// アイコンの描画
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
		
		bt.redraw();
		disp();
	}
}

// ユーザーが最小化したウィンドウをドラッグしているときに表示するカーソルを取得するために、
//  システムがこの関数を呼び出します。
HCURSOR CimageViewerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}




//ＯＫボタン*****************************
void CimageViewerDlg::OnBnClickedOk()
{

	//CDialogEx::OnOK();
}

//キャンセル***********************************************
void CimageViewerDlg::cancel()
{
	GdiplusShutdown(token);//GDI+解放

	if (!imgBack0.IsNull()) {
		imgBack0.ReleaseDC();
	}

	if (!imgBack.IsNull()) {
		imgBack.ReleaseDC();
	}

	if (!imgBT.IsNull()) {
		imgBT.ReleaseDC();
	}

	DeleteObject(hbrHaikei);

	ReleaseDC(pDC);

	CDialogEx::OnCancel();
}



//背景の変更**********************************************************
HBRUSH CimageViewerDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	if (nCtlColor == CTLCOLOR_DLG) {
		hbr = hbrHaikei;
	}

	return hbr;
}



//CbuttonDlgからのメッセージ（メイン・ボタン）***************************
LRESULT  CimageViewerDlg::OnBT(WPARAM wParam, LPARAM lParam)
{
	if (lParam == 0) {
		return 0;
	}

	switch (wParam) {

	case 0: //ロード・イメージ
		file(0);
		break;

	case 1: //表示サイズ切り替え
		if (imgW > 0 && imgH > 0) {
			changeAuto_100();
		}
		break;

	case 5: //セーブ・イメージ
		if (imgW > 0 && imgH > 0) {
			file(1);
		}
		break;

	case 6://Window最小化
		this->ShowWindow(SW_SHOWMINIMIZED);
		break;

	case 7://Window最大化（現在禁止）
		break;

	case 8: //キャンセル（X）
		cancel();
		break;

	default:
		break;
	}

	return 0;
}



//Lボタン・ダウン**************************************************
void CimageViewerDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	POINT pt;
	GetCursorPos(&pt);
	mxDW = pt.x;
	myDW = pt.y;
	ScreenToClient(&pt);
	mxD = (int)(pt.x);
	myD = (int)(pt.y);

	bmxM = mxD;
	bmyM = myD;

	KillTimer(1);
	zV = 0.0f;

	fg_moveWindow = 0;


	if (mxD > 0 && mxD < Width - 240 && myD>0 && myD < btH / 2 - 12) {	//ムーブWindow
		fg_moveWindow = 1;
		GetWindowRect(&WRECT);
		return;
	}



	CDialogEx::OnLButtonDown(nFlags, point);
}


//マウス・ムーブ*****************************************************
void CimageViewerDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	POINT pt;
	GetCursorPos(&pt);
	mxMW = pt.x;
	myMW = pt.y;
	ScreenToClient(&pt);
	int mxM = (int)(pt.x);
	int myM = (int)(pt.y);


	if (nFlags == MK_LBUTTON && fg_moveWindow == 1) {	//Windowムーブ
		int Dw = WRECT.right - WRECT.left;
		int Dh = WRECT.bottom - WRECT.top;
		MoveWindow(WRECT.left + (mxMW - mxDW), WRECT.top +
			(myMW - myDW), Dw, Dh, TRUE);	//TRUE=再描画
		return;
	}

	if (nFlags == MK_LBUTTON && mxM > 0 && mxM<VWidth && myM>btH && myM < VHeight) {
		scroll(mxM, myM);
	}

	CDialogEx::OnMouseMove(nFlags, point);
}



//Lボタン・アップ**********************************************
void CimageViewerDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient(&pt);
	mxU = (int)(pt.x);
	myU = (int)(pt.y);

	KillTimer(1);
	zV = 0.0f;

	//ボタンスキャン
	if (mxU > 0 && mxU < Width && myU>0 && myU < btH) {
		bt.scanBT(mxD, myD, mxU, myU);
		return;
	}

	bsX = sX;
	bsY = sY;

	CDialogEx::OnLButtonUp(nFlags, point);
}



//画像スクロール*********************************************************************************
void CimageViewerDlg::scroll(int mxm, int mym)
{
	if (imgWZ > VWidth) {
		sX = bsX + (int)((float)(mxD - mxm) / zBi);
		VX0 = sX - (int)((float)VWidth / 2.0 / zBi);

		if (VX0 < 0) {
			VX0 = 0;
			sX = bsX = (int)((float)VWidth / 2.0 / zBi);
			mxD = mxm;
		}
		else if (VX0 > imgW - (int)((float)VWidth / zBi)) {
			VX0 = imgW - (int)((float)VWidth / zBi);
			sX = bsX = imgW - (int)((float)VWidth / 2.0 / zBi);
			mxD = mxm;
		}

		VX1 = sX + (int)((float)VWidth / 2.0 / zBi);
	}

	if (imgHZ > VHeight) {
		sY = bsY + (int)((float)(myD - mym) / zBi);
		VY0 = sY - (int)((float)VHeight / 2.0 / zBi);

		if (VY0 < 0) {
			VY0 = 0;
			sY = bsY = (int)((float)VHeight / 2.0 / zBi);
			myD = mym;
		}
		else if (VY0 > imgH - (int)((float)VHeight / zBi)) {
			VY0 = imgH - (int)((float)VHeight / zBi);
			sY = bsY = imgH - (int)((float)VHeight / 2.0 / zBi);
			myD = mym;
		}

		VY1 = sY + (int)((float)VHeight / 2.0 / zBi);
	}

	//スクリーン・バッファにストレッチ
	clearBack(hdcBack, VWidth, VHeight, Haikei);
	pdcBack->StretchBlt(ofBX, ofBY, VWidth - ofBX * 2, VHeight - ofBY * 2,
		pdcBack0, VX0, VY0, VX1 - VX0, VY1 - VY0, SRCCOPY);
	disp();
}


//マウスホイール****************************************************************
BOOL CimageViewerDlg::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	hwZD = (int)zDelta;
	KillTimer(1);
	tmCT = 0;
	zStep = 0.0f;
	float K = 0.002f;

	zV += (float)zDelta * K;
	if (imgW > 0 && imgH > 0) {
		SetTimer(1, 10, NULL);
	}

	return CDialogEx::OnMouseWheel(nFlags, zDelta, pt);
}


//タイマー***********************************************************************
void CimageViewerDlg::OnTimer(UINT_PTR nIDEvent)
{
	if (imgW <= 0 || imgH <= 0) {
		return;
	}

	//マウス・ホイール
	float ref = 60.0f;
	float friction = 0.90f;

	switch (nIDEvent) {
	case 1://zoom
		zV *= friction;
		float base = ref / (float)imgW / (float)VWidth * (float)imgWZ;
		zStep = base * zV;

		zoom();

		if (fabs(zV) < 0.001f)
		{
			zV = 0.0f;
			KillTimer(1);
		}
		break;
	}

	CDialogEx::OnTimer(nIDEvent);
}


//Zoom **********************************************************************************************
void CimageViewerDlg::zoom()
{
	bt.fg_auto = 0;

	zBi = zBi + zStep;// 0.01f;

	zStep = 0.0f;

	//リミッタ
	if (imgW < Width && imgH < Height) {
		if (zBi * (float)imgW < (float)imgW * 0.5f) {
			zBi = bzBi;
		}
	}
	else {
		if (imgW >= imgH) {
			if (zBi * (float)imgW <= 500.0f) {
				zBi = bzBi;
			}
		}
		else {
			if (zBi * (float)imgH <= 500.0f) {
				zBi = bzBi;
			}
		}
	}

	if (zBi >= 2.0f) {
		zBi = 2.0f;
	}

	bzBi = zBi;


	imgWZ = (int)((float)imgW * zBi);
	imgHZ = (int)((float)imgH * zBi);

	if (imgWZ < VWidth) {
		sX = bsX = imgW / 2;
	}
	if (imgHZ < VHeight) {
		sY = bsY = imgH / 2;
	}

	if (imgWZ < VWidth) {
		VX0 = 0;
		VX1 = imgW;
		ofBX = VWidth / 2 - imgWZ / 2;
	}
	else {
		VX0 = bsX - (int)((float)VWidth / zBi / 2.0f);

		if (VX0 < 0) {
			VX0 = 0;
			sX = bsX = (int)((float)VWidth / 2.0f / zBi);
			mxD = mxM;
		}
		else if (VX0 > imgW - (int)((float)VWidth / zBi)) {
			VX0 = imgW - (int)((float)VWidth / zBi);
			sX = bsX = imgW - (int)((float)VWidth / 2.0f / zBi);
			mxD = mxM;
		}

		VX1 = bsX + (int)((float)VWidth / zBi / 2.0f);

		ofBX = 0;
	}

	if (imgHZ < VHeight) {
		VY0 = 0;
		VY1 = imgH;
		ofBY = VHeight / 2 - imgHZ / 2;
	}
	else {
		VY0 = bsY - (int)((float)VHeight / zBi / 2.0f);

		if (VY0 < 0) {
			VY0 = 0;
			sY = bsY = (int)((float)VHeight / 2.0f / zBi);
			myD = myM;
		}
		else if (VY0 > imgH - (int)((float)VHeight / zBi)) {
			VY0 = imgH - (int)((float)VHeight / zBi);
			sY = bsY = imgH - (int)((float)VHeight / 2.0f / zBi);
			myD = myM;
		}

		VY1 = bsY + (int)((float)VHeight / zBi / 2.0f);

		ofBY = 0;
	}

	//スクリーン・バッファにストレッチ
	clearBack(hdcBack, VWidth, VHeight, Haikei);
	pdcBack->StretchBlt(ofBX, ofBY, VWidth - ofBX * 2, VHeight - ofBY * 2,
		pdcBack0, VX0, VY0, VX1 - VX0, VY1 - VY0, SRCCOPY);

	disp();

	bt.drawZPersent(zBi);
}


//Auto表示、100%表示切り替え******************************************************
void CimageViewerDlg::changeAuto_100()
{
	if (bt.fg_auto == 1) {//Auto表示
		zBi = autozBi;

		imgWZ = (int)((float)imgW * zBi);
		imgHZ = (int)((float)imgH * zBi);

		sX = imgW / 2;
		sY = imgH / 2;

		bsX = sX;
		bsY = sY;

		//初期表示範囲
		VX0 = 0;
		VX1 = imgW;
		ofBX = VWidth / 2 - imgWZ / 2;

		VY0 = 0;
		VY1 = imgH;
		ofBY = VHeight / 2 - imgHZ / 2;

		//スクリーン・バッファにストレッチ
		clearBack(hdcBack, VWidth, VHeight, Haikei);
		pdcBack->StretchBlt(ofBX, ofBY, VWidth - ofBX * 2, VHeight - ofBY * 2,
			pdcBack0, VX0, VY0, VX1 - VX0, VY1 - VY0, SRCCOPY);

		disp();
	}
	else {//100%表示
		zBi = 1.0;

		imgWZ = (int)((float)imgW * zBi);
		imgHZ = (int)((float)imgH * zBi);

		sX = imgW / 2;
		sY = imgH / 2;

		bsX = sX;
		bsY = sY;

		if (imgWZ < VWidth) {
			VX0 = 0;
			VX1 = imgW;
			ofBX = VWidth / 2 - imgWZ / 2;
		}
		else {
			VX0 = sX - (int)((float)VWidth / zBi / 2.0);
			VX1 = sX + (int)((float)VWidth / zBi / 2.0);
			ofBX = 0;
		}

		if (imgHZ < VHeight) {
			VY0 = 0;
			VY1 = imgH;
			ofBY = VHeight / 2 - imgHZ / 2;
		}
		else {
			VY0 = sY - (int)((float)VHeight / zBi / 2.0);
			VY1 = sY + (int)((float)VHeight / zBi / 2.0);
			ofBY = 0;
		}

		//スクリーン・バッファにストレッチ
		clearBack(hdcBack, VWidth, VHeight, Haikei);
		pdcBack->StretchBlt(ofBX, ofBY, VWidth - ofBX * 2, VHeight - ofBY * 2,
			pdcBack0, VX0, VY0, VX1 - VX0, VY1 - VY0, SRCCOPY);

		disp();
	}
}




//ファイル（開く、保存）****************************************************************
void CimageViewerDlg::file(int fg)
{
	CString strFilter;
	strFilter = _T("すべて|*.*|.png|*.png|.bmp|*.bmp|.tif|*.tif|.jpg|*.jpg|");
	BOOL RW = TRUE;
	CString name = _T("");
	DWORD dwFlags = OFN_FILEMUSTEXIST;

	if (fg == 1) {
		RW = FALSE;
		name = _T("無題.jpg");
		dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_EXPLORER;
	}

	CFileDialog fDlg(RW, _T("*.*"), name, dwFlags, strFilter);
	int retR = (int)fDlg.DoModal();
	if (retR != IDOK) {
		return;
	}
	
	CString filePath = fDlg.GetPathName();
	
	if (fg == 0) {//ロード
		if (loadImage(filePath) == S_OK) {
			CString strW;
			strW.Format(_T("%d"), imgW);
			CString strH;
			strH.Format(_T("%d"), imgH);

			bt.WText = _T("imageViewer        ") + filePath + _T("　　　　　") +
				strW + _T("　X　") + strH;
			bt.redraw();
		}
	}
	else {//セーブ
		saveImage(filePath);
	}
}



//ロード・イメージ*******************************************************************
int CimageViewerDlg::loadImage(CString filePath)
{
	::SetCursor(AfxGetApp()->LoadStandardCursor(IDC_WAIT));

	//loadImage---------------------------------------------------------------
	Img = NULL;
	Img = Image::FromFile(filePath);	//画像の情報を取得

	if (Img->GetLastStatus() != Gdiplus::Ok) {
		delete Img;
		Img = NULL;
		return -1;
	}

	imgW = (int)Img->GetWidth();
	imgH = (int)Img->GetHeight();

	//画像サイズオーバーは、リサイズ
	float bi = 1.0f;
	if (imgW > imgWmax) {
		bi = (float)imgWmax / (float)imgW;
	}

	if ((int)((float)imgH * bi) > imgHmax) {
		float bi = (float)imgH / (float)imgHmax;
	}

	if (bi < 1.0f) {
		imgW = (int)((float)imgW * bi);
		imgH = (int)((float)imgH * bi);
	}

	sX = imgW / 2;
	sY = imgH / 2;

	bsX = sX;
	bsY = sY;

	//初期のZoom倍率
	if (imgW > VWidth || imgH > VHeight) {

		zBi = (float)VHeight * 1.0f / (float)imgH;
		if (imgW * zBi >= VWidth) {
			zBi = (float)VWidth * 0.9f / (float)imgW;
		}
	}
	else {
		zBi = 1.0;
	}

	bzBi = zBi;

	autozBi = zBi;

	imgWZ = (int)((float)imgW * zBi);	//auto zoomされたイメージの幅
	imgHZ = (int)((float)imgH * zBi);	//auto zoomされたイメージの高さ


	//初期表示範囲
	VX0 = 0;
	VX1 = imgW;
	ofBX = VWidth / 2 - imgWZ / 2;

	VY0 = 0;
	VY1 = imgH;
	ofBY = VHeight / 2 - imgHZ / 2;

	//imgW,imgHに合わせた元画像編集用バッファを作成
	if (!imgBack0.IsNull()) {
		imgBack0.ReleaseDC();
	}
	imgBack0.Destroy();
	imgBack0.CreateEx(imgW, imgH, 32, BI_RGB, 0, CImage::createAlphaChannel);
	pdcBack0 = CDC::FromHandle(imgBack0.GetDC());
	hdcBack0 = pdcBack0->GetSafeHdc();
	clearBack(hdcBack0, imgW, imgH, Haikei);

	::SetCursor(AfxGetApp()->LoadStandardCursor(IDC_WAIT));

	//imgBack0に画像を（ロード・コピー）
	clearBack(hdcBack0, imgW, imgH, Haikei);
	
	Rect rect = { 0,0,imgW,imgH };
	Graphics g(hdcBack0);
	g.DrawImage(Img, rect);	//ここで、画像データーが読み込まれる
	delete Img;

	//スクリーン・バッファにストレッチ
	clearBack(hdcBack, VWidth, VHeight, Haikei);
	pdcBack->StretchBlt(ofBX, ofBY, VWidth - ofBX * 2, VHeight - ofBY * 2,
		pdcBack0, VX0, VY0, VX1 - VX0, VY1 - VY0, SRCCOPY);

	//ボタン・リセット
	bt.reset();
	bt.redraw();

	disp();

	return 0;
}



//表示***********************************************************************
void CimageViewerDlg::disp()
{
	pDC->BitBlt(0, ofY, VWidth, VHeight, pdcBack, 0, 0, SRCCOPY);
}




//Backバッファを任意の色でクリア************************************
void CimageViewerDlg::clearBack(HDC hdc, int w, int h, COLORREF Col)
{
	RECT rect = { 0,0,w,h };
	CBrush cbr(Col);
	FillRect(hdc, &rect, (HBRUSH)cbr);
	cbr.DeleteObject();
}



//セーブ・イメージ************************************************************
void CimageViewerDlg::saveImage(CString filePath)
{
	if (imgW <= 0 || imgH <= 0) {
		return;
	}

	::SetCursor(AfxGetApp()->LoadStandardCursor(IDC_WAIT));

	GUID guid_type = GUID_NULL;

	if (filePath.Right(4) == _T(".png") || filePath.Right(4) == _T(".PNG")) {
		guid_type = Gdiplus::ImageFormatPNG;
	}
	else if (filePath.Right(4) == _T(".tif") || filePath.Right(4) == _T(".TIF")) {
		guid_type = Gdiplus::ImageFormatTIFF;
	}
	else if (filePath.Right(4) == _T(".bmp") || filePath.Right(4) == _T(".BMP")) {
		guid_type = Gdiplus::ImageFormatBMP;
	}
	else if (filePath.Right(4) == _T(".jpg") || filePath.Right(4) == _T(".JPG")) {
		guid_type = Gdiplus::ImageFormatJPEG;
	}

	if (guid_type != GUID_NULL) {

		imgBack0.Save(filePath, guid_type);
	}
}

