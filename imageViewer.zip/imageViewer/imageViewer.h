﻿
// imageViewer.h : PROJECT_NAME アプリケーションのメイン ヘッダー ファイルです
//

#pragma once

#ifndef __AFXWIN_H__
	#error "PCH に対してこのファイルをインクルードする前に 'pch.h' をインクルードしてください"
#endif

#include "resource.h"		// メイン シンボル


// CimageViewerApp:
// このクラスの実装については、imageViewer.cpp を参照してください
//

class CimageViewerApp : public CWinApp
{
public:
	CimageViewerApp();

// オーバーライド
public:
	virtual BOOL InitInstance();

// 実装

	DECLARE_MESSAGE_MAP()
};

extern CimageViewerApp theApp;
